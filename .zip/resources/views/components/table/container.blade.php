<div {{ $attributes->merge(['class' => 'relative overflow-x-auto shadow-md sm:rounded-lg']) }}>
    {{ $slot }}
</div>