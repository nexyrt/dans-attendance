<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        {{-- Favicon --}}
        <link rel="icon" href="{{ asset('images/dans.png') }}">

        {{-- Fonts --}}
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

        {{-- Styles --}}
        <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
        @notifyCss
        @livewireStyles
        @vite(['resources/css/app.css', 'resources/js/app.js'])

        <style>
            [x-cloak] {
                display: none !important;
            }

            body {
                font-family: 'Poppins', sans-serif;
            }
        </style>
        @laravelPWA
    </head>

    <body class="bg-gray-50">


        <div x-data="{ isSidebarOpen: false }" class="min-h-screen">
            <!-- Mobile Header -->
            <div class="lg:hidden fixed top-0 left-0 right-0 bg-white h-16 border-b border-gray-100 z-30 px-4">
                <div class="flex items-center justify-between h-full">
                    <button @click="isSidebarOpen = !isSidebarOpen"
                        class="p-2 rounded-lg text-gray-600 hover:bg-gray-100">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path x-show="!isSidebarOpen" stroke-linecap="round" stroke-linejoin="round"
                                stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                            <path x-show="isSidebarOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                    <div class="text-xl font-semibold text-primary-600">Dans Attendance</div>
                    <div class="flex items-center">
                        <img class="h-8 w-8 rounded-full object-cover"
                            src="{{ auth()->user()->profile_photo_url ?? asset('images/default-avatar.png') }}"
                            alt="{{ auth()->user()->name }}">
                    </div>
                </div>
            </div>

            <div class="flex h-screen overflow-hidden">
                <!-- Sidebar -->
                <aside
                    class="fixed inset-y-0 left-0 z-20 w-64 bg-white shadow-sm transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0 flex flex-col"
                    :class="{ 'translate-x-0': isSidebarOpen, '-translate-x-full': !isSidebarOpen }">

                    <!-- Logo Section -->
                    <div class="flex-shrink-0 px-5 py-4 border-b border-gray-100">
                        <h1 class="text-xl font-semibold text-primary-600">Dans Attendance</h1>
                    </div>

                    <!-- Navigation -->
                    <nav class="flex-1 px-4 py-6 overflow-y-auto">
                        <a href="{{ route('staff.dashboard') }}"
                            @click.prevent="window.innerWidth < 1024 ? (isSidebarOpen = false, window.location.href = '{{ route('staff.dashboard') }}') : window.location.href = '{{ route('staff.dashboard') }}'"
                            class="flex items-center text-gray-600 px-3 py-2.5 text-sm font-medium rounded-lg {{ request()->routeIs('staff.dashboard') ? 'bg-primary-50 text-primary-600' : 'hover:bg-gray-50' }}">
                            <svg class="w-5 h-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                            </svg>
                            Dashboard
                        </a>
                    </nav>

                    <!-- User Profile Section -->
                    <div class="flex-shrink-0 border-t border-gray-100 p-4">
                        <!-- User profile content remains the same -->
                        <div class="flex items-center space-x-3">
                            <img class="h-9 w-9 rounded-full object-cover"
                                src="{{ auth()->user()->profile_photo_url ?? asset('images/default-avatar.png') }}"
                                alt="{{ auth()->user()->name }}">
                            <div class="min-w-0 flex-1">
                                <p class="text-sm font-medium text-gray-900 truncate">{{ auth()->user()->name }}</p>
                                <p class="text-xs text-gray-500 truncate">{{ auth()->user()->email }}</p>
                            </div>
                        </div>
                    </div>
                </aside>

                <!-- Main Content Wrapper -->
                <div class="flex-1">
                    <!-- Main Content -->
                    <div class="flex flex-col min-h-screen">
                        <!-- Header -->
                        <header class="bg-white shadow-sm">
                            <div class="px-6 py-4">
                                <h1 class="text-xl font-semibold text-gray-900">{{ $title ?? 'Dashboard' }}</h1>
                            </div>
                        </header>

                        <!-- Content Area -->
                        <main class="flex-1">
                            <div class="p-6">
                                {{ $slot }}
                            </div>
                        </main>
                    </div>
                </div>
            </div>
        </div>

        {{-- Modals & Notifications --}}
        <livewire:shared.check-in-modal />
        <livewire:shared.check-out-modal />

        @livewireScripts
    </body>

</html>
