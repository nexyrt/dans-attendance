<x-layouts.admin>
    <livewire:admin.leave.leave-dashboard />
</x-layouts.admin>