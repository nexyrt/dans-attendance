<x-layouts.admin>
    <livewire:admin.office.office-location />
</x-layouts.admin>