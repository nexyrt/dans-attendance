<x-layouts.admin>
    @livewire('admin.users.user-detail', ['user' => $user])
</x-layouts.admin>