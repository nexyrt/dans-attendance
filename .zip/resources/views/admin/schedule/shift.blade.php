<x-layouts.admin>
    <livewire:admin.schedules.schedule-table />
</x-layouts.admin>