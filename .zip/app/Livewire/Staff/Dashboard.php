<?php

namespace App\Livewire\Staff;

use Livewire\Component;

class Dashboard extends Component
{
    public function render()
    {
        return view('livewire.staff.dashboard')
            ->layout('layouts.staff', ['title' => 'Dashboard']);
    }
}
